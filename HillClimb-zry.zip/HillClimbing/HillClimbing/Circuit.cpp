#include "Circuit.h"


Circuit::Circuit(void)
{
	x = 0;
	g = 0;
	y = 0;
}


Circuit::~Circuit(void)
{
}

Status Circuit::openFile(string filepath)
{
	ifstream in(filepath);

	for(string s;getline(in, s);)
	{
		switch(s[0])
		{
		case 'I': addInput(s);break;
		case 'O': addOutput(s);break;
		case 'G': addGate(s);break;
		}
	}


	in.clear();
	in.seekg(0,ios::beg);

	for(string s;getline(in, s);)
	{
		switch(s[0])
		{
		case 'O': perOutput(s);break;
		case 'G': perGate(s);break;
		}
	}

	in.close();

	return OK;
}

Status Circuit::addInput(string str)
{
	GateNode gn;
	int i = 6;
	while(str[i] != ')')
		i ++;
	
	gn.setType(input);
	gn.name = str.substr(6,i - 6);
	gate.push_back(gn);
	x ++;

	return OK;
}

Status Circuit::addOutput(string str)
{
	GateNode gn;
	int i = 7;
	while(str[i] != ')')
		i ++;
	
	gn.setType(output);
	gn.name = str.substr(7,i - 7);
	gate.push_back(gn);
	y ++;

	return OK;
}

Status Circuit::addGate(string str)
{
	GateNode gn;
	int i = 0;
	int j = 0;
	while(str[i] != ' ')
		i ++;
	
	gn.name = str.substr(0, i);
	
	j = i + 3;
	while(str[i] != '(')
		i ++;

	string s = str.substr(j, i - j);
	gn.setType(judgeType(s));
	gate.insert(gate.begin() + x + g, gn);
	g++;
	
	return OK;
}


Status Circuit::perOutput(string str)
{
	int i = 7;
	while(str[i] != ')')
		i ++;
	
	int to = searchOutput(str.substr(7,i - 7));
	int tg = searchGate(str.substr(7,i - 7));

	gate[to].pioneer.push_back(&gate[tg]);
	gate[tg].successor.push_back(&gate[to]);
	gate[tg].weight ++;

	return OK;
}

Status Circuit::perGate(string str)
{
	int i = 0;
	int j = 0;

	while(str[i] != 't')
		i ++;

	int current = searchGate(str.substr(0, ++ i));
	int target = 0;

	while(str[i] != '(')
		i ++;

	while(str[i] != ')')
	{
		if(str[i] == 'G')
			j = i;

		if(str[i] == 't')
		{
			target = searchGate(str.substr(j, i - j + 1));
			gate[current].pioneer.push_back(&gate[target]);
			gate[target].successor.push_back(&gate[current]);
			gate[target].weight ++;
		}
		i ++;
	}

	return OK;
}

int Circuit::searchInput(string str)
{
	int i = 0;
	for(;i < x; i ++)
	{
		if(str == gate[i].name)
			return i;
	}
	return -1;
}

int Circuit::searchOutput(string str)
{
	int i = x + g;
	for(;i < x + g + y; i ++)
	{
		if(str == gate[i].name)
			return i;
	}
	return -1;
}

int Circuit::searchGate(string str)
{
	int i = 0;
	for(;i < x + g; i ++)
	{
		if(str == gate[i].name)
			return i;
	}
	return -1;
}

GateType Circuit::judgeType(string type)
{
	if(type == "not")
		return not;
	else if(type == "and")
		return and;
	else if(type == "or")
		return or;
	else if(type == "nand")
		return nand;
	else if(type == "nor")
		return nor;
	else if(type == "xor")
		return xor;
	else if(type == "nxor")
		return nxor;
	else 
		return null;
}

Status Circuit::inputToCircuit(vector<int> input, vector<int> &output, vector<int> &gateStatus)
{
	if(input.size() != x || output.size() != y || gateStatus.size() != g)
		return ERROR;

	for(unsigned int i = 0; i < gate.size(); i++)
		gate[i].value = -1;

	for(int i = 0; i < x; i ++)
		gate[i].setValue(input[i]);

	for(int i = 0; i < y; i ++)
	{
		gate[x + g + i].getValue();
		output[i] = gate[x + g + i].value;
	}
	
	for(int i = 0; i < g; i ++)
		gateStatus[i] = gate[x + i].value;

	return OK;
}

int Circuit::powerSingle(vector<int> inputBoth)
{
	if(inputBoth.size() != 2 * x)
		return ERROR;

	int power = 0;
	vector<int> inputOne, inputTwo, gateStatusOne(g), gateStatusTwo(g), outputOne(y), outputTwo(y);

	for(int i = 0; i < x; i ++)
		inputOne.push_back(inputBoth[i]);
	for(int i = x; i < 2 * x; i ++)
		inputTwo.push_back(inputBoth[i]);

	inputToCircuit(inputOne, outputOne, gateStatusOne);
	inputToCircuit(inputTwo, outputTwo, gateStatusTwo);

	/*for(int i = 0; i < x; i ++)
	{
		cout<<inputOne[i];
	}
	cout<<endl;

	for(int i = 0; i < g; i ++)
	{
		cout<<gateStatusOne[i];
	}
	cout<<endl;

	for(int i = 0; i < x; i ++)
	{
		cout<<inputTwo[i];
	}
	cout<<endl;

	for(int i = 0; i < g; i ++)
	{
		cout<<gateStatusTwo[i];
	}
	cout<<endl;*/

	for(int i = 0; i < g; i ++)
	{
		if(gateStatusOne[i] != gateStatusTwo[i])
			power += gate[x + i].weight;
	}

	return power;
}