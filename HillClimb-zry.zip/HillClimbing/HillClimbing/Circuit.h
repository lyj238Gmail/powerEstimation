#pragma once
#include <fstream>
#include"GateNode.h"


class Circuit
{
public:
	int x;                      //������Ŀ
	int g;                      //�߼�����Ŀ
	int y;                      //�����Ŀ

	vector<GateNode> gate;      //������

public:
	Circuit(void);
	~Circuit(void);

	Status openFile(string);

	Status addInput(string);
	Status addOutput(string);
	Status addGate(string);

	Status perOutput(string);
	Status perGate(string);

	int searchInput(string);
	int searchOutput(string);
	int searchGate(string);

	GateType judgeType(string);

	Status inputToCircuit(vector<int>, vector<int> &, vector<int> &);
	int powerSingle(vector<int>);

	
};

