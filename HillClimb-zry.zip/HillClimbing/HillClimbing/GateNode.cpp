#include "GateNode.h"


GateNode::GateNode(void)
{
	value = -1;
	weight = 0;
	type = null;
}


GateNode::~GateNode(void)
{

}

Status GateNode::operator = (GateNode g)
{
	value = g.value;
	weight = g.weight;
	name = g.name;
	type = g.type;

	return OK;
}

Status GateNode::setValue(int v)
{
	if(v <= 0)
		value = 0;
	else 
		value = 1;

	return OK;
}

Status GateNode::setType(GateType t)
{
	type = t;
	return OK;
}

Status GateNode::getValue()
{
	switch(type)
	{
		case null:break;
		case input:break;
		case output:_Output();break;
		case not:_Not();break;
		case and:_And();break;
		case or:_Or();break;
		case nand:_Nand();break;
		case nor:_Nor();break;
		case xor:_Xor();break;
		case nxor:_Nxor();break;
	}

	return OK;
}

Status GateNode::_Output()
{
	if(pioneer.size() != 1)
		return ERROR;

	if(pioneer[0]->value == -1)
		pioneer[0]->getValue();

	value = pioneer[0]->value;

	return OK;
}

Status GateNode::_Not()
{
	if(pioneer.size() != 1)
		return ERROR;

	if(pioneer[0]->value == -1)
		pioneer[0]->getValue();
	
	value = 1 - pioneer[0]->value;

	return OK;
}

Status GateNode::_And()
{
	if(pioneer.size() < 1)
		return ERROR;

	int _v = 1;

	for(unsigned int i = 0; i < pioneer.size(); i ++)
	{
		if(pioneer[i]->value == -1)
			pioneer[i]->getValue();

		_v *= pioneer[i]->value;
	}
	
	setValue(_v);
	return OK;
}

Status GateNode::_Or()
{
	if(pioneer.size() < 1)
		return ERROR;

	int _v = 0;

	for(unsigned int i = 0; i < pioneer.size(); i ++)
	{
		if(pioneer[i]->value == -1)
			pioneer[i]->getValue();

		_v += pioneer[i]->value;
	}
	
	setValue(_v);
	return OK;
}

Status GateNode::_Nand()
{
	if(pioneer.size() < 1)
		return ERROR;

	int _v = 1;

	for(unsigned int i = 0; i < pioneer.size(); i ++)
	{
		if(pioneer[i]->value == -1)
			pioneer[i]->getValue();

		_v *= pioneer[i]->value;
	}
	
	setValue(1 - _v);
	return OK;
}

Status GateNode::_Nor()
{
	if(pioneer.size() < 1)
		return ERROR;

	int _v = 0;

	for(unsigned int i = 0; i < pioneer.size(); i ++)
	{
		if(pioneer[i]->value == -1)
			pioneer[i]->getValue();

		_v += pioneer[i]->value;
	}
	
	setValue(1 - _v);
	return OK;
}

Status GateNode::_Xor()
{
	if(pioneer.size() != 2)
		return ERROR;


	if(pioneer[0]->value == -1)
		pioneer[0]->getValue();

	if(pioneer[1]->value == -1)
		pioneer[1]->getValue();

	if(pioneer[0]->value != pioneer[1]->value)
	{
		value = 1;
		return OK;
	}
	
	value = 0;
	return OK;
}

Status GateNode::_Nxor()
{
	if(pioneer.size() != 2)
		return ERROR;


	if(pioneer[0]->value == -1)
		pioneer[0]->getValue();

	if(pioneer[1]->value == -1)
		pioneer[1]->getValue();

	if(pioneer[0]->value != pioneer[1]->value)
	{
		value = 0;
		return OK;
	}
	
	value = 1;
	return OK;
}