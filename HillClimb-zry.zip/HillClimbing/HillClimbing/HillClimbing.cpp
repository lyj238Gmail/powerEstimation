// HillClimbing.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include "Circuit.h"
using namespace std;

//�����ת���һλ
vector<int> randomOf(vector<int> v)
{
	int i = rand() % v.size();
	v[i] = 1 - v[i];
	return v;
}

//��ɽ��
int hillClimb(Circuit &c)
{
	int now = 0;
	int result = 0;
	//��ǰ�ڵ㣬 �ھӽڵ�
	vector<int> current(2 * c.x);
	vector<int> neighbor(2 * c.x);

	//��ʼ�������
	srand(100);

	for(int i = 0; i < 1000; i ++)
	{
		neighbor = randomOf(current);
		now = c.powerSingle(neighbor);
		if(now > result)
		{
			result = now;
			current = neighbor;
		}
	}
	for(int i = 0; i < 2 * c.x; i ++)
		cout<<current[i];

	cout<<endl;

	return result;
}

int main()
{
	Circuit c;
	c.openFile("D:\\bench432.txt");

	vector<int> current(c.x), output(c.y), gate(c.g);
	
	/*for(int i = 0; i < 50; i ++)
	{
		c.inputToCircuit(current,output,gate);

		for(unsigned int i = 0; i < current.size(); i ++)
			cout<<current[i];
		cout<<endl;

		for(unsigned int i = 0; i < gate.size(); i ++)
			cout<<gate[i];
		cout<<endl;

		for(unsigned int i = 0; i < output.size(); i ++)
			cout<<output[i];
		cout<<endl<<endl;

		current = randomOf(current);

	}*/

	cout<<hillClimb(c)<<endl;

	/*int a[] = {1,1,0,0,1,1};
	vector<int> v(a, a+ 6);
	cout<<c.powerSingle(v)<<endl;*/

	/*for(unsigned int i = 0; i < c.gate.size(); i ++)
	{
		cout<<c.gate[i].name<<"\tp:";
		for(unsigned int j = 0; j < c.gate[i].pioneer.size(); j ++)
			cout<<c.gate[i].pioneer[j]->name<<",";

		cout<<"\t\ts:";
		for(unsigned int j = 0; j < c.gate[i].successor.size(); j ++)
			cout<<c.gate[i].successor[j]->name<<",";

		cout<<"\t\tw:"<<c.gate[i].weight;

		cout<<endl;
	}*/
	
	/*for(int i = 0; i < c.x; i ++)
		c.gate[i].value = 0;


	for(int i = 0; i < c.y; i ++)
		c.gate[c.x + c.g + i].getValue();

	for(unsigned int i = 0; i < c.gate.size(); i ++)
		cout<<c.gate[i].type<<"\t"<<c.gate[i].name<<":"<<c.gate[i].value<<endl;

	cout<<c.x<<endl;
	cout<<c.g<<endl;
	cout<<c.y<<endl;*/

	return 0;
}

