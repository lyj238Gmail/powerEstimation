#include "ex.h"

int numVars=0;
map<string,int> mapStr2Int;
map <string, int>::iterator Iter;
vector<DdNode*> bddVect;
vector<string> bvars;
DdManager* manager = Cudd_Init(0,0,CUDD_UNIQUE_SLOTS,CUDD_CACHE_SLOTS,0);;
DdNode* resultPtr;
DdNode* tempPtr;
DdNode* opdPtr;
DdNode* opd1Ptr;
DdNode* opd2Ptr;

void mk_and(string s, struct names a)
{
  int i=0;
  if(a.n==1){
  opdPtr = bddVect[mapStr2Int[a.svec[0]]];
  resultPtr = opdPtr;  
  Cudd_Ref(resultPtr);
  bddVect.insert(bddVect.end(),1,resultPtr);
  mapStr2Int[s] = numVars;
  cout<<s<<"--->"<<mapStr2Int[s]<<endl;
  numVars++;
  }
  else{
  opd1Ptr = bddVect[mapStr2Int[a.svec[i]]];
  opd2Ptr = bddVect[mapStr2Int[a.svec[++i]]];
  while(a.n>2&&i<a.n-1)
  {
    tempPtr = Cudd_bddAnd(manager,opd1Ptr,opd2Ptr);
    Cudd_Ref(tempPtr);
    opd1Ptr = tempPtr;
    opd2Ptr = bddVect[mapStr2Int[a.svec[++i]]];
  }
  resultPtr = Cudd_bddAnd(manager,opd1Ptr,opd2Ptr);
  Cudd_Ref(resultPtr);
  bddVect.insert(bddVect.end(),1,resultPtr);
  mapStr2Int[s]=numVars;
  cout<<s<<"--->"<<mapStr2Int[s]<<endl;
  numVars++;
  }
}

void mk_or(string s, struct names a)
{
  int i=0;
  opd1Ptr = bddVect[mapStr2Int[a.svec[i]]];
  opd2Ptr = bddVect[mapStr2Int[a.svec[++i]]];
  while(a.n>2&&i<a.n-1)
  {
    tempPtr = Cudd_bddOr(manager,opd1Ptr,opd2Ptr);
    Cudd_Ref(tempPtr);
    opd1Ptr = tempPtr;
    opd2Ptr = bddVect[mapStr2Int[a.svec[++i]]];
  }
  resultPtr = Cudd_bddOr(manager,opd1Ptr,opd2Ptr);
  Cudd_Ref(resultPtr);
  bddVect.insert(bddVect.end(),1,resultPtr);
  mapStr2Int[s]=numVars;
  cout<<s<<"--->"<<mapStr2Int[s]<<endl;
  numVars++;
}

void mk_nor(string s, struct names a)
{
  int i=0;
  opd1Ptr = bddVect[mapStr2Int[a.svec[i]]];
  opd2Ptr = bddVect[mapStr2Int[a.svec[++i]]];
  while(a.n>2&&i<a.n-1)
  {
    tempPtr = Cudd_bddOr(manager,opd1Ptr,opd2Ptr);
    Cudd_Ref(tempPtr);
    opd1Ptr = tempPtr;
    opd2Ptr = bddVect[mapStr2Int[a.svec[++i]]];
  }
  tempPtr = Cudd_bddOr(manager,opd1Ptr,opd2Ptr);
  resultPtr = Cudd_Not(tempPtr);
  Cudd_Ref(resultPtr);
  bddVect.insert(bddVect.end(),1,resultPtr);
  mapStr2Int[s]=numVars;
  cout<<s<<"--->"<<mapStr2Int[s]<<endl;
  numVars++;

}


void mk_nand(string s, struct names a)
{
  int i=0;
  if(a.n==1){
  opdPtr = bddVect[mapStr2Int[a.svec[0]]];
  resultPtr = Cudd_Not(opdPtr);  
  Cudd_Ref(resultPtr);
  bddVect.insert(bddVect.end(),1,resultPtr);
  mapStr2Int[s] = numVars;
  cout<<s<<"--->"<<mapStr2Int[s]<<endl;
  numVars++;
  }
  else{
  opd1Ptr = bddVect[mapStr2Int[a.svec[i]]];
  opd2Ptr = bddVect[mapStr2Int[a.svec[++i]]];
  while(a.n>2&&i<a.n-1)
  {
    tempPtr = Cudd_bddAnd(manager,opd1Ptr,opd2Ptr);
    Cudd_Ref(tempPtr);
    opd1Ptr = tempPtr;
    opd2Ptr = bddVect[mapStr2Int[a.svec[++i]]];
  }
  tempPtr = Cudd_bddAnd(manager,opd1Ptr,opd2Ptr);
  resultPtr = Cudd_Not(tempPtr);
  Cudd_Ref(resultPtr);
  bddVect.insert(bddVect.end(),1,resultPtr);
  mapStr2Int[s]=numVars;
  cout<<s<<"--->"<<mapStr2Int[s]<<endl;
  numVars++;
 }
}

void mk_buf(string s, struct names a)
{
  opdPtr = bddVect[mapStr2Int[a.svec[0]]];
  resultPtr = opdPtr;
  Cudd_Ref(resultPtr);
  bddVect.insert(bddVect.end(),1,resultPtr);
  mapStr2Int[s] = numVars;
  cout<<s<<"--->"<<mapStr2Int[s]<<endl;
  numVars++;
}

void mk_not(string s, struct names a)
{
  opdPtr = bddVect[mapStr2Int[a.svec[0]]];
  resultPtr = Cudd_Not(opdPtr);  
  Cudd_Ref(resultPtr);
  bddVect.insert(bddVect.end(),1,resultPtr);
  mapStr2Int[s] = numVars;
  cout<<s<<"--->"<<mapStr2Int[s]<<endl;
  numVars++;
}

void mk_xor(string s, struct names a)
{
  int i=0;
  opd1Ptr = bddVect[mapStr2Int[a.svec[i]]];
  opd2Ptr = bddVect[mapStr2Int[a.svec[++i]]];
  resultPtr = Cudd_bddXor(manager, opd1Ptr, opd2Ptr);
  Cudd_Ref(resultPtr);
  bddVect.insert(bddVect.end(), 1, resultPtr);
  mapStr2Int[s] = numVars;
  cout<<s<<"--->"<<mapStr2Int[s]<<endl;
  numVars++;
}

void mk_xnor(string s, struct names a)
{
  int i=0;
  opd1Ptr = bddVect[mapStr2Int[a.svec[i]]];
  opd2Ptr = bddVect[mapStr2Int[a.svec[++i]]];
  resultPtr = Cudd_bddXnor(manager, opd1Ptr, opd2Ptr);
  Cudd_Ref(resultPtr);
  bddVect.insert(bddVect.end(), 1, resultPtr);
  mapStr2Int[s] = numVars;
  cout<<s<<"--->"<<mapStr2Int[s]<<endl;
  numVars++;
}


void showname(string s,struct names a)
{
  int i;
  cout<<".names ";
  for(i=0;i<a.n;++i)
    cout<<a.svec[i]<<" ";
  cout<<s<<endl;
}

void mk_init(string *s)
{
  resultPtr = Cudd_bddIthVar(manager, numVars);
  Cudd_Ref(resultPtr);
  bddVect.insert(bddVect.end(), 1, resultPtr);
  mapStr2Int[*s]=numVars;
  cout<<*s<<"--->"<<mapStr2Int[*s]<<endl;
  numVars++;
  bvars.push_back(*s);
}

struct names* mk_id(string *s)
{
  struct names *a=new struct names;
  a->n=1;
  (a->svec).push_back(*s);
  return a;
}

struct names* mk_list(struct names* a, string *s)
{
  struct names* b=new struct names;
  b->n=a->n+1;
  b->svec=a->svec;
  (b->svec).push_back(*s);
  return b;
}


