#include <iostream>
#include <stdio.h>
#include <string>
#include <vector>
#include <map>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "cudd.h"
#include "util.h"



using namespace std;




struct names{
  int n;
  vector<string> svec;
};

struct exps{
  int t;
  struct names s;
};

void mk_and(string , struct names );
void mk_nand(string , struct names );
void mk_or(string , struct names );
void mk_nor(string , struct names );
void mk_xor(string , struct names );
void mk_xnor(string , struct names );
void mk_buf(string , struct names );
void mk_not(string , struct names );

void mk_init(string*);

struct names* mk_id(string*);

struct names* mk_list(struct names*, string*);

void showname(string , struct names );


