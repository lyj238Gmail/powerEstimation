extern "C"

#include <iostream>
#include <vector>
#include <string>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <fstream>
#include <map>
#include "util.h"
#include "cudd.h"
#include "cuddInt.h"
#include <regex.h>
//#include "cuddObj.hh"

using namespace std;

void CreatNeighbors(vector<string>& neighbors, string obj)
{
	int len = obj.length();
	for(int i = 0; i < len; i++)
	{
		string temp;
		if(obj.at(i) == '0') temp = obj.substr(0,i)+"1"+obj.substr(i+1);
		else temp = obj.substr(0,i)+"0"+obj.substr(i+1);
		neighbors.push_back(temp);
	}
}

DdNode* CreatRestrict(DdManager *manager, string obj)
{
	DdNode * res;
	if(obj.at(0) == '1') res = Cudd_bddIthVar(manager, 0);
	else res = Cudd_Not(Cudd_bddIthVar(manager, 0));
	Cudd_Ref(res);
	int len = obj.length();
	for(int i = 1; i < len; i++)
	{
		if(obj.at(i) == '0') res = Cudd_bddAnd(manager, res, Cudd_Not(Cudd_bddIthVar(manager, i)));
		else res = Cudd_bddAnd(manager, res, Cudd_bddIthVar(manager, i));
		//Cudd_Ref(res);引用数没有增加
	}
	return res;
}

int subsitute(DdManager *manager, DdNode **node, DdNode * restricts, vector<int> weightedlist)
{
	//DdNode * innerRestrict;
	int sum = 0;
	int loop = weightedlist.size();
	DdNode *res;
	for(int i = 0; i < loop; i++)
	{
		res = Cudd_bddRestrict(manager, node[i], restricts);
		Cudd_Ref(res);
		if((res->type).value == true) sum += weightedlist.at(i);
		Cudd_RecursiveDeref(manager, res);
	}
	return sum;
}

string init(int len)
{
	string res;
	srand((unsigned)time(NULL));
	for(int i = 0; i < len; i++)
	{
		if(rand()%2 == 0) res += "0";
		else res += "1";
	}
	return res;
}

void HL(DdManager *manager, DdNode **node, vector<string> bvars, vector<int> weightedlist)
{
	bool stop = false;
	string bestassign = init(bvars.size());
	vector<string> neighbors;
	int bestweight = subsitute(manager, node, CreatRestrict(manager, bestassign), weightedlist);
	while(!stop)
	{
		stop = true;
		int innerbest;
		CreatNeighbors(neighbors, bestassign);
		vector<string>::iterator ite = neighbors.begin();
		for(; ite != neighbors.end(); ite++)
		{
			innerbest = subsitute(manager, node, CreatRestrict(manager, (*ite)), weightedlist);
			if(innerbest > bestweight)
			{
				bestweight = innerbest;
				bestassign = (*ite);
				stop = false;
			}
		}
		neighbors.clear();
	}
	cout<<"the best assignment counted by HL is: "<<bestweight<<endl;
	int j = 0;
	for(std::vector<std::string>::iterator i = bvars.begin(); i != bvars.end(); i++)
	{
		cout<<(*i)<<" assigns: "<<bestassign.at(j)<<endl;
		j++;
	}
}

#define ACCURACY 100000
float my_random()
{
	//srand(time(NULL));
	/* generate secret number: */
	int rdm = rand() % ACCURACY;
	return (float)rdm/(float)ACCURACY;
}

int random(int len)
{
	//srand(time(NULL));
	/* generate secret number: */
	return rand() % len;
}

void SA(DdManager *manager, DdNode **node, vector<string> bvars, vector<int> weightedlist)
{
	srand(time(NULL));
	string bestassign = init(bvars.size());
	vector<string> neighbors;
	int bestweight = subsitute(manager, node, CreatRestrict(manager, bestassign), weightedlist);
	int loop = bvars.size();
	while(loop--)
	{
		CreatNeighbors(neighbors, bestassign);
		vector<string>::iterator ite = neighbors.begin();
		int temp_best;
		string loop_best_assign;
		while(ite != neighbors.end())
		{
			temp_best = subsitute(manager, node, CreatRestrict(manager, bestassign), weightedlist);
			int inc = temp_best - bestweight;
			if(inc >= 0)
			{
				bestassign = (*ite);
				bestweight = temp_best;
			}
			else if(pow(2, inc) > my_random())
			{
				bestassign = (*ite);
				bestweight = temp_best;
			}
			ite++;
		}
		neighbors.clear();
	}

	cout<<"the best assignment counted by SA  is: "<<bestweight<<endl;
	int j = 0;
	for(std::vector<std::string>::iterator i = bvars.begin(); i != bvars.end(); i++)
	{
		cout<<(*i)<<" assigns: "<<bestassign.at(j)<<endl;
		j++;
	}
}

//n 是种群数量 len是基因个数 即输入变量的个数 population是中群众所有个体的基因
void iniPopulation(int n, int len, vector< pair<string, int> >& population)
{
	map<string, int> stuffs;
	string child;
	//map 保证去重
	while(stuffs.size() < n)
	{
		child = init(len);
		stuffs.insert(make_pair(child, 0));
	}

	map<string, int>::iterator ite = stuffs.begin();
	//将map中没有重复的基因个体保存到准群中
	while(ite != stuffs.end())
	{
		population.push_back(*ite);
		++ite;
	}
}

int parentsIndex(vector<float> probilities)
{
	//for(vector<float>::iterator ite = probilities.begin(); ite != probilities.end(); ite++) cout<<(*ite)<<endl;
	//返回 0-1之间的 保留6位有效数字的小数
	//等概率
	float check = my_random();
	//cout<<"the check number: "<<check<<endl;
	int index = 0;
	while(index < probilities.size()-1)
	{
		if(check >= probilities.at(index) && check < probilities.at(index+1)) return index;
		index++;
	}
	return 0;
}

void ProbAsParent(vector< pair<string, int> > population, vector<float>& probilities)
{
	int weightsum = 0;
	vector< pair<string, int> >::iterator ite = population.begin();
	int min_weight = ite->second;
	while(ite != population.end())
	{
		if(min_weight > ite->second) min_weight = ite->second;
		weightsum += ite->second;
		++ite;
	}

	int prob_cal = weightsum - (population.size() * (min_weight - 1));
	//cout<<"the prob_cal is: "<<prob_cal<<endl;
	//cout<<"the min_weigh is: "<<min_weight<<endl;
	ite = population.begin();
	//轮转法计算每个个体作为父体发生的概率
	while(ite != population.end())
	{
		probilities.push_back((float)(ite->second - min_weight + 1)/(float)prob_cal);
		++ite;
	}
}

string corss_gen(string fa, string ma)
{
	//遗传过的父母各一半的基因
	return fa.substr(0, (fa.length()/2)) + ma.substr(fa.length()/2);
}

string change(string child, int generation)
{
	float prob = (float)generation/(float)(child.length());
	float check = my_random();
	if(check > prob)
	{
		int i = random(child.length());
		return (child.at(i) == '0') ? child.substr(0,i)+"1"+child.substr(i+1) : child.substr(0,i)+"0"+child.substr(i+1);
	}
	return child;
}
void Generate(vector< pair<string, int> >& population, int len, int generation, DdManager *manager, DdNode **node, vector<int> weightedlist)
{
	//cout<<"the initial size is: "<<population.size()<<endl;
	vector<float> probilities;
	ProbAsParent(population, probilities);
	
	//存储生育后的所有种群个体
	map<string, int> new_generation;

	//长生了不多于len个个体
	int childNum = len;
	while(childNum--)
	{
		//cout<<"the current len is: "<<len<<endl;
		//选定双亲
		//轮转法 weight值越大 被选中的概率越大
		int fa = parentsIndex(probilities);
		//cout<<"before parentsIndex: "<<endl;
		int ma = parentsIndex(probilities);

		string child = corss_gen(population.at(fa).first, population.at(ma).first);
		//执行变异
		//代数越多 越稳定 变异发生的概率越小
		string child_after_change = change(child, generation);
		new_generation.insert(make_pair(child_after_change, subsitute(manager, node, CreatRestrict(manager, child_after_change), weightedlist)));
		//cout<<"the inner loop new_generation size is: "<<new_generation.size()<<endl;
	}
	//cout<<"the new_generation size is: "<<new_generation.size()<<endl;
	vector< pair<string, int> >::iterator ite = population.begin();
	//利用map的自动去重功能
	for(; ite!= population.end(); ite++)
	{
		new_generation.insert(*ite);
	}
	population.clear();
	//cout<<"after insert popu the new_generation size is: "<<new_generation.size()<<endl;
	//对new_generation中的个体进行排序 然后取更新后的新种群 并存入population中
	for(int i = 0; i < len; i++)
	{
		map<string, int>::iterator inner_ite;
		map<string, int>::iterator cur = new_generation.begin();
		for(inner_ite = new_generation.begin(); inner_ite != new_generation.end(); ++inner_ite)
		{
			if(cur->second < inner_ite->second) cur = inner_ite;
		}
		//cout<<i<<endl;
		population.push_back(make_pair(cur->first, cur->second));
		//cout<<"inside size: "<<population.size()<<endl;
		new_generation.erase(cur);
	}
	//cout<<"population size is: "<<population.size()<<endl;
}

void GA(DdManager *manager, DdNode **node, vector<string> bvars, vector<int> weightedlist)
{
	//
	//种群初始化
	//
	//种群数量 初步定义为输入个数
	int num_of_population = bvars.size();
	//染色体长度
	int len = bvars.size();
	//种群基因及初始化
	vector< pair<string, int> > population;
	iniPopulation(num_of_population, len, population);
	//初始种群的评价结果
	int temp_best;
	srand(time(NULL));
	vector< pair<string, int> >::iterator ite = population.begin();
	while(ite != population.end())
	{
		temp_best = subsitute(manager, node, CreatRestrict(manager, ite->first), weightedlist);
		ite->second = temp_best;
		++ite;
	}
	
	//main loop
	//每一次循环就是更替一代
	int generation = bvars.size();
	//cout<<"time "<<generation<<endl;
	while(generation--)
	{
		//cout<<"time "<<generation<<endl;
		//for(vector< pair<string, int> >::iterator ite = population.begin(); ite != population.end(); ite++) cout<<ite->first<<" --- "<<ite->second<<endl;
		Generate(population, len, generation, manager, node, weightedlist);
	}

	//最好的后代
	string bestassign = population.at(0).first;
	//输出结果
	cout<<"the best assignment counted by GA is: "<<population.at(0).second<<endl;
	int j = 0;
	for(std::vector<std::string>::iterator i = bvars.begin(); i != bvars.end(); i++)
	{
		cout<<(*i)<<" assigns: "<<bestassign.at(j)<<endl;
		j++;
	}
}

/*void getWeightedlist(string filename, vector<int>& weightedlist,map<string,int>& mapStr2Int)
{
	ifstream out;
	char nodeName[256];
	char *weight;
	char *colon;
	out.open(filename.c_str(), ios::in);
	string line;
	while(!out.eof()){
		std::getline(out,line);
		colon = strchr(line.c_str(),',');
		bcopy(line.c_str(),nodeName,(colon-line.c_str()/sizeof(char)));
		printf(nodeName);
		weight = colon+sizeof(char);
		colon[0] = 0;
		weightedlist[mapStr2Int[nodeName]] = (atoi(weight));
	}
	out.close();
}*/

static char* substr(const char*str, unsigned start, unsigned end)
{
	unsigned n = end - start;
	//static char stbuf[256];
	char *stbuf;
	stbuf = (char *)malloc(n *sizeof(char));
	strncpy(stbuf, str + start, n);
	stbuf[n] = 0;
	return stbuf;
}

void getWeightedlist(char* filename, vector<int>& weightedlist,map<string,int>& mapStr2Int)
{
	FILE *infile;
	char line[256];
	char *weight;
	char *colon;
	char *nodeName;

	infile = fopen(filename,"r");
  
	while ( fgets ( line, sizeof ( line ), infile ))
	{
		colon = strchr(line,',');
		nodeName = substr(line,0,(colon-line)/sizeof(char));
		printf(nodeName);
		weight = colon + sizeof(char);
		weightedlist[mapStr2Int[nodeName]] = (atoi(weight));
	}
	fclose(infile);
}


//my code to compile xored circuits to bexprList
DdNode** compile(char* fileName, 
	 vector<DdNode*> &bddVect,
	 DdManager *manager,
	 vector<string>& bvars, 
	 map<string,int>& mapStr2IntOfWeightedList,
	 int& count)
{
	FILE *infile;
	char * patternOfInput = "INPUT";
	char * patternOfOutput = "OUTPUT";
	char * patternOfNand = "nand";
	char * patternOfXor = "xor";
	char * patternOfAnd = "and";
	char * patternOfXnor = "xnor";
	char * patternOfOr = "or";
	char * patternOfNor = "nor";
	char * patternOfBuf = "buf";
	char * patternOfNot = "not";
	char * patternOfLeftBracket = "(";
	char * patternOfColon = ",";
	char * patternOfRightBracket = ")";
	char * patternOfComment = "#";
	char * patternOfXorNode = "*XOR*";
	char *patternOfId = "[A-Za-z0-9*_]+";

	regex_t regOfInput;
	regex_t regOfOutput;
	regex_t regOfNand;
	regex_t regOfLeftBracket;
	regex_t regOfColon;
	regex_t regOfRightBracket;
	regex_t regOfComment;
	regex_t regOfId;
	regex_t regOfXor;
	regex_t regOfXnor;
	regex_t regOfNor;
	regex_t regOfOr;
	regex_t regOfNot;
	regex_t regOfBuf;
	regex_t regOfAnd;
	regex_t regOfXorNode;

	int x, z, lno = 0, cflags = 0,matchMode=REG_NOTBOL;
	char ebuf[128], lbuf[256];
	regex_t reg;
	regmatch_t pm[10];
	const size_t nmatch = 10, REG_MATCH = 0;
	int leftOpdPos = 0, para1Pos = 0, para2Pos = 0, oprPos = 0;

	char *leftBuf = NULL;
	char *opd1Buf = NULL;
	char *opd2Buf = NULL;
	char *oprBuf = NULL;
	char *left = NULL;
	char *opd1 = NULL;
	char *opd2 = NULL;
	char *opr = NULL;
	char outBuf[256];


	int numNodes = 0,inputVars = 0;
	map<string,int> mapStr2Int;
	map <string, int>::iterator Iter;

	// = Cudd_Init(0,0,CUDD_UNIQUE_SLOTS,CUDD_CACHE_SLOTS,0);;
	DdNode* resultPtr;
	DdNode* opd1Ptr;
	DdNode* opd2Ptr;
	DdNode** retDDodeArr;
	//string str;
	/* 编译正则表达式*/
	/*patternOfId = argv[1];*/
	infile=fopen(fileName,"r");

	z = regcomp(&regOfInput, patternOfInput, cflags);
	z = regcomp(&regOfOutput, patternOfOutput, cflags);
	z = regcomp(&regOfNand, patternOfNand, cflags);
	z = regcomp(&regOfLeftBracket, patternOfLeftBracket, cflags);
	z = regcomp(&regOfColon, patternOfColon, cflags);
	z = regcomp(&regOfRightBracket, patternOfRightBracket, cflags);
	z = regcomp(&regOfComment, patternOfComment, cflags);
	z = regcomp(&regOfXor, patternOfXor, cflags);
	z = regcomp(&regOfXnor, patternOfXnor, cflags);
	z = regcomp(&regOfAnd, patternOfAnd, cflags);
	z = regcomp(&regOfOr, patternOfOr, cflags);
	z = regcomp(&regOfNor, patternOfNor, cflags);
	z = regcomp(&regOfNot, patternOfNot, cflags);
	z = regcomp(&regOfBuf, patternOfBuf, cflags);
	z = regcomp(&regOfId, patternOfId, REG_ICASE|REG_EXTENDED);
	z = regcomp(&regOfXorNode, patternOfXorNode, cflags);

	sprintf(outBuf,"%d",z);
	printf("%s,%s\n",outBuf,patternOfId);

	/* 逐行处理输入的数据 */
	while(fgets (lbuf, sizeof(lbuf), infile))
	{
	    ++lno;
	    /*???*/
	    printf("%d", lno);
	    printf("%s\n",lbuf);
	    if((z = strlen(lbuf)) > 0 && lbuf[z-1] == '\n')
	    {
		lbuf[z - 1] = 0;
		/* 对每一行应用正则表达式进行匹配 */

		if((z = regexec (&regOfComment, lbuf, nmatch, pm, matchMode)) == REG_MATCH) continue;
		//deal with INPUT x
		else if((z = regexec(&regOfInput, lbuf, nmatch, pm, matchMode)) == REG_MATCH)
		{
		    regexec( &regOfLeftBracket, lbuf, nmatch, pm, matchMode );
		    if( z == REG_NOMATCH ) {printf( "nomatch:(\n");continue;};
		    
		    leftOpdPos = pm[0].rm_eo ;
		    /*opdStr=substr(lbuf,leftOpdPos,strlen(lbuf));*/
		    leftBuf = lbuf + leftOpdPos*sizeof ( char );
		    z = regexec ( &regOfId, leftBuf, 1, pm, REG_NOTBOL);
		    
		    sprintf ( outBuf,"%d,%d,%d\n",z,pm[0].rm_so, pm[0].rm_eo);
		    left = substr( leftBuf, pm[0].rm_so, pm[0].rm_eo );
		    //printf ( "Input: z,z,pm[0].rm_so,pm[0].rm_eo:=%s,lef=%s,leftBuf=%s\n", outBuf, left, leftBuf );
		    
		    //new map item; new the ith bdd var
		    resultPtr = Cudd_bddIthVar(manager,numNodes);
		    Cudd_Ref(resultPtr);
		    bddVect.insert(bddVect.end(),1,resultPtr);
		    mapStr2Int[left] = numNodes;
		    inputVars++;
		    numNodes++;
		    bvars.push_back(left);       
		}
		else if((z = regexec(&regOfOutput, lbuf, nmatch, pm, matchMode)) == REG_MATCH) continue;
		else if((z = regexec(&regOfNand, lbuf, nmatch, pm, matchMode)) == REG_MATCH)
		{
		    regexec( &regOfId, lbuf, nmatch, pm, matchMode );
		    left = substr( lbuf,pm[0].rm_so, pm[0].rm_eo );
		    regexec ( &regOfLeftBracket, lbuf, nmatch, pm, matchMode );
		    para1Pos = pm[0].rm_eo ;
		    opd1Buf = lbuf + para1Pos*sizeof ( char );
		    regexec ( &regOfId, opd1Buf, 1, pm, matchMode );
		    opd1 = substr( opd1Buf,pm[0].rm_so, pm[0].rm_eo );
		    opd2Buf = opd1Buf + pm[0].rm_eo*sizeof ( char );
		    regexec( &regOfId, opd2Buf, 1, pm, matchMode )  ;
		    opd2 = substr (opd2Buf,pm[0].rm_so, pm[0].rm_eo );
		    //printf( "Nand: %s,%s,%s,\n", left, opd1,opd2 );

		    opd1Ptr = bddVect[mapStr2Int[opd1]];
		    opd2Ptr = bddVect[mapStr2Int[opd2]];
		    resultPtr =  Cudd_bddNand(manager, opd1Ptr, opd2Ptr);
		    Cudd_Ref(resultPtr);
		    bddVect.insert(bddVect.end(),1,resultPtr);
		    mapStr2Int[left] = numNodes;
		    numNodes++;
		}
		else if((z = regexec(&regOfXor, lbuf, nmatch, pm, matchMode)) == REG_MATCH )
		{
		    regexec( &regOfId, lbuf, nmatch, pm, matchMode );
		    left = substr( lbuf,pm[0].rm_so, pm[0].rm_eo );
		    regexec( &regOfLeftBracket, lbuf, nmatch, pm, matchMode );
		    para1Pos = pm[0].rm_eo ;
		    opd1Buf = lbuf + para1Pos*sizeof ( char );
		    regexec ( &regOfId, opd1Buf, 1, pm, matchMode );
		    opd1 = substr ( opd1Buf,pm[0].rm_so, pm[0].rm_eo );
		    opd2Buf = opd1Buf + pm[0].rm_eo*sizeof ( char );
		    regexec( &regOfId, opd2Buf, 1, pm, matchMode )  ;
		    opd2 = substr (opd2Buf,pm[0].rm_so, pm[0].rm_eo );
		    //printf( "Nand: %s,%s,%s,\n", left, opd1,opd2 );

		    opd1Ptr = bddVect[mapStr2Int[opd1]];
		    opd2Ptr = bddVect[mapStr2Int[opd2]];
		    resultPtr =  Cudd_bddXor(manager, opd1Ptr, opd2Ptr);
		    Cudd_Ref(resultPtr);
		    bddVect.insert(bddVect.end(),1,resultPtr);
		    mapStr2Int[left] = numNodes;
		    numNodes++;
		}
		else if((z = regexec(&regOfXnor, lbuf, nmatch, pm, matchMode)) == REG_MATCH)
		{
		    regexec(&regOfId, lbuf, nmatch, pm, matchMode);
		    left = substr( lbuf,pm[0].rm_so, pm[0].rm_eo);
		    regexec (&regOfLeftBracket, lbuf, nmatch, pm, matchMode);
		    para1Pos = pm[0].rm_eo;
		    opd1Buf = lbuf + para1Pos*sizeof(char);
		    regexec(&regOfId, opd1Buf, 1, pm, matchMode);
		    opd1 = substr(opd1Buf,pm[0].rm_so, pm[0].rm_eo);
		    opd2Buf = opd1Buf + pm[0].rm_eo*sizeof (char);
		    regexec(&regOfId, opd2Buf, 1, pm, matchMode);
		    opd2 = substr(opd2Buf,pm[0].rm_so, pm[0].rm_eo);
		    //printf ( "Nand: %s,%s,%s,\n", left, opd1,opd2 );

		    opd1Ptr = bddVect[mapStr2Int[opd1]];
		    opd2Ptr = bddVect[mapStr2Int[opd2]];
		    resultPtr =  Cudd_bddXnor(manager, opd1Ptr, opd2Ptr);
		    Cudd_Ref(resultPtr);
		    bddVect.insert(bddVect.end(), 1, resultPtr);
		    mapStr2Int[left] = numNodes;
		    numNodes++;
		}
		else if((z = regexec (&regOfOr, lbuf, nmatch, pm, matchMode)) == REG_MATCH)
		{
		    regexec(&regOfId, lbuf, nmatch, pm, matchMode);
		    left = substr(lbuf,pm[0].rm_so, pm[0].rm_eo);
		    regexec (&regOfLeftBracket, lbuf, nmatch, pm, matchMode);
		    para1Pos = pm[0].rm_eo ;
		    opd1Buf = lbuf + para1Pos*sizeof(char);
		    regexec(&regOfId, opd1Buf, 1, pm, matchMode);
		    opd1 = substr(opd1Buf,pm[0].rm_so, pm[0].rm_eo);
		    opd1Ptr = bddVect[mapStr2Int[opd1]];
		    opd2Buf = opd1Buf + pm[0].rm_eo*sizeof(char);
		    while((z = regexec(&regOfId, opd2Buf, 1, pm, matchMode)) == REG_MATCH)
		    {
			opd2 = substr(opd2Buf,pm[0].rm_so, pm[0].rm_eo);
			//printf("Nand: %s,%s,%s,\n", left, opd1, opd2);
			opd2Ptr = bddVect[mapStr2Int[opd2]];
		    	resultPtr = Cudd_bddOr(manager, opd1Ptr, opd2Ptr);
			Cudd_Ref(resultPtr);
		    	bddVect.insert(bddVect.end(),1,resultPtr);
		    	opd1Ptr = resultPtr;
		    	opd2Buf = opd2Buf + pm[0].rm_eo*sizeof(char);
		    	numNodes++;
		    }
		    mapStr2Int[left] = numNodes - 1;
		}
		else if((z = regexec(&regOfNor, lbuf, nmatch, pm, matchMode)) == REG_MATCH )
		{
		    regexec(&regOfId, lbuf, nmatch, pm, matchMode);
		    left = substr(lbuf,pm[0].rm_so, pm[0].rm_eo);
		    regexec(&regOfLeftBracket, lbuf, nmatch, pm, matchMode);
		    para1Pos = pm[0].rm_eo ;
		    opd1Buf = lbuf + para1Pos*sizeof(char);
		    regexec(&regOfId, opd1Buf, 1, pm, matchMode);
		    opd1 = substr(opd1Buf,pm[0].rm_so, pm[0].rm_eo);
		    opd2Buf = opd1Buf + pm[0].rm_eo*sizeof(char);
		    regexec(&regOfId, opd2Buf, 1, pm, matchMode);
		    opd2 = substr(opd2Buf,pm[0].rm_so, pm[0].rm_eo);
		    //printf("Nand: %s,%s,%s,\n", left, opd1,opd2);

		    opd1Ptr = bddVect[mapStr2Int[opd1]];
		    opd2Ptr = bddVect[mapStr2Int[opd2]];
		    resultPtr = Cudd_bddNor(manager, opd1Ptr, opd2Ptr);
		    Cudd_Ref(resultPtr);
		    bddVect.insert(bddVect.end(), 1, resultPtr);
		    mapStr2Int[left] = numNodes;
		    numNodes++;
		}
		else if((z = regexec(&regOfAnd, lbuf, nmatch, pm, matchMode)) == REG_MATCH )
		{
		    regexec(&regOfId, lbuf, nmatch, pm, matchMode);
		    left = substr(lbuf,pm[0].rm_so, pm[0].rm_eo );
		    regexec(&regOfLeftBracket, lbuf, nmatch, pm, matchMode);
		    para1Pos = pm[0].rm_eo ;
		    opd1Buf = lbuf+para1Pos*sizeof(char);
		    regexec(&regOfId, opd1Buf, 1, pm, matchMode);
		    opd1 = substr (opd1Buf,pm[0].rm_so, pm[0].rm_eo);
		    opd1Ptr = bddVect[mapStr2Int[opd1]];
		    opd2Buf = opd1Buf + pm[0].rm_eo*sizeof(char);
		    while((z = regexec(&regOfId, opd2Buf, 1, pm, matchMode)) == REG_MATCH ) 
		    {
			opd2 = substr(opd2Buf,pm[0].rm_so, pm[0].rm_eo);        	  
			opd2Ptr = bddVect[mapStr2Int[opd2]];
		    	resultPtr =  Cudd_bddAnd(manager, opd1Ptr, opd2Ptr);
			Cudd_Ref(resultPtr);
		    	bddVect.insert(bddVect.end(), 1, resultPtr);
		    	opd1Ptr = resultPtr;
		    	opd2Buf = opd2Buf + pm[0].rm_eo*sizeof(char);
		    	numNodes++;
			//printf("Nand: %s,%s,%s,\n", left, opd1, opd2);
		    }
		    mapStr2Int[left] = numNodes - 1;
		    
		}
		else if((z = regexec(&regOfNand, lbuf, nmatch, pm, matchMode)) == REG_MATCH)
		{
		    regexec(&regOfId, lbuf, nmatch, pm, matchMode);
		    left = substr(lbuf,pm[0].rm_so, pm[0].rm_eo);
		    regexec(&regOfLeftBracket, lbuf, nmatch, pm, matchMode);
		    para1Pos = pm[0].rm_eo ;
		    opd1Buf = lbuf + para1Pos*sizeof(char);
		    regexec(&regOfId, opd1Buf, 1, pm, matchMode);
		    opd1 = substr(opd1Buf,pm[0].rm_so, pm[0].rm_eo);
		    opd2Buf = opd1Buf + pm[0].rm_eo*sizeof(char);
		    regexec(&regOfId, opd2Buf, 1, pm, matchMode);
		    opd2 = substr(opd2Buf,pm[0].rm_so, pm[0].rm_eo);
		    //printf("Nand: %s,%s,%s,\n", left, opd1,opd2);
		    opd1Ptr = bddVect[mapStr2Int[opd1]];
		    opd2Ptr = bddVect[mapStr2Int[opd2]];
		    resultPtr =  Cudd_bddNand(manager, opd1Ptr, opd2Ptr);
		    Cudd_Ref(resultPtr);
		    bddVect.insert(bddVect.end(), 1, resultPtr);
		    mapStr2Int[left] = numNodes;
		    numNodes++;
		}
		else if((z = regexec(&regOfNot, lbuf, nmatch, pm, matchMode)) == REG_MATCH)
		{
		    regexec(&regOfId, lbuf, nmatch, pm, matchMode);
		    left = substr(lbuf,pm[0].rm_so, pm[0].rm_eo);
		    regexec(&regOfLeftBracket, lbuf, nmatch, pm, matchMode);
		    para1Pos = pm[0].rm_eo ;
		    opd1Buf = lbuf + para1Pos*sizeof(char);
		    regexec(&regOfId, opd1Buf, 1, pm, matchMode);
		    opd1 = substr(opd1Buf,pm[0].rm_so, pm[0].rm_eo);
		    //printf("Not: %s,%s,%s,\n", left, opd1);
		    opd1Ptr = bddVect[mapStr2Int[opd1]];
		    resultPtr = Cudd_Not(opd1Ptr);
		    Cudd_Ref(resultPtr);
		    bddVect.insert(bddVect.end(), 1, resultPtr);
		    mapStr2Int[left] = numNodes;
		    numNodes++;
		}
		else if((z = regexec(&regOfBuf, lbuf, nmatch, pm, matchMode)) == REG_MATCH)
		{
		    regexec(&regOfId, lbuf, nmatch, pm, matchMode);
		    left = substr(lbuf,pm[0].rm_so, pm[0].rm_eo);
		    regexec(&regOfLeftBracket, lbuf, nmatch, pm, matchMode);
		    para1Pos = pm[0].rm_eo ;
		    opd1Buf = lbuf + para1Pos*sizeof(char);
		    regexec(&regOfId, opd1Buf, 1, pm, matchMode)  ;
		    opd1 = substr(opd1Buf,pm[0].rm_so, pm[0].rm_eo);
		    //printf("buf: %s,%s,%s,\n", left, opd1);
		    opd1Ptr = bddVect[mapStr2Int[opd1]];
		    resultPtr = opd1Ptr;
		    Cudd_Ref(resultPtr);
		    bddVect.insert(bddVect.end(), 1, resultPtr);
		    mapStr2Int[left] = numNodes;
		    numNodes++;
		}
	    }
	}
	/* 释放正则表达式 */


	count = 0;
	for( Iter = mapStr2Int.begin(); Iter != mapStr2Int.end(); Iter++)
	{
		//cout<<(Iter->first)<<"--->"<<(Iter->second)<<endl;
		if((z = regexec (&regOfXorNode, (Iter->first).c_str(), nmatch, pm, matchMode)) == REG_MATCH) count++;
	}


	retDDodeArr = new DdNode*[count];
	count = 0;
	for( Iter = mapStr2Int.begin(); Iter != mapStr2Int.end(); Iter++)
	{
	  if( z = regexec( &regOfXorNode, (Iter->first).c_str(), nmatch, pm, matchMode)) == REG_MATCH)
		{
			//cout<<(Iter->first)<<"--->"<<(Iter->second)<<endl;
			mapStr2IntOfWeightedList[(Iter->first)] = count;
			retDDodeArr[count] = bddVect[Iter->second];
			count++;
		}
	}


	/*for (x = inputVars; x < bddVect.size(); x++)
	{
		retDDodeArr[x-inputVars] = bddVect[x];
	}

	for( Iter = mapStr2Int.begin(); Iter != mapStr2Int.end(); Iter++ )
		cout<<(Iter->first)<<"--->"<<(Iter->second)<<endl;*/

	regfree(&regOfInput);
	regfree(&regOfOutput);
	regfree(&regOfId);
	regfree(&regOfNand);
	regfree(&regOfColon);
	regfree(&regOfLeftBracket);
	regfree(&regOfRightBracket);
	regfree(&regOfComment);
	regfree(&regOfXor);
	regfree(&regOfXorNode);
	fclose(infile);

	return retDDodeArr;

}




int main(int argc, char** argv)
{
	DdManager *manager;
	map<string,int> mapStr2IntOfWeightedList;
	manager = Cudd_Init(0, 0, CUDD_UNIQUE_SLOTS, CUDD_CACHE_SLOTS, 0);

	//如下产生论文中的电路为例子
	//输入分别为以下
	vector<string> bvars;
	/*bvars.push_back("x0");
	bvars.push_back("x1");
	bvars.push_back("x2");
	bvars.push_back("y0");
	bvars.push_back("y1");
	bvars.push_back("y2");
	//权中
	vector<int> weightedlist;
	weightedlist.push_back(1);
	weightedlist.push_back(2);
	weightedlist.push_back(1);
	weightedlist.push_back(1);
	//编号
	DdNode *x0 = Cudd_bddIthVar(manager, 0);
	DdNode *x1 = Cudd_bddIthVar(manager, 1);
	DdNode *x2 = Cudd_bddIthVar(manager, 2);
	DdNode *y0 = Cudd_bddIthVar(manager, 3);
	DdNode *y1 = Cudd_bddIthVar(manager, 4);
	DdNode *y2 = Cudd_bddIthVar(manager, 5);
	//构造inner gate
	DdNode *f1 = Cudd_Not(x0);
 	Cudd_Ref(f1);

	DdNode *f2 = Cudd_bddNand(manager, x0, x1);
	Cudd_Ref(f2);

	DdNode *f3 = Cudd_bddNand(manager, f1, f2);
	Cudd_Ref(f3);

	DdNode *f4 = Cudd_bddXor(manager, x2, f2);
	Cudd_Ref(f4);

	//构造inner gate
	DdNode *f11 = Cudd_Not( y0);
 	Cudd_Ref(f11);

	DdNode *f22 = Cudd_bddNand(manager, y0, y1);
	Cudd_Ref(f22);

	DdNode *f33 = Cudd_bddNand(manager, f11, f22);
	Cudd_Ref(f33);

	DdNode *f44 = Cudd_bddXor(manager, y2, f22);
	Cudd_Ref(f44);


	DdNode **nodes =  new DdNode *[4];
	//构造xor
	DdNode *node0 = Cudd_bddXor(manager, f1, f11);
	Cudd_Ref(node0);
	DdNode *node1 = Cudd_bddXor(manager, f2, f22);
	Cudd_Ref(node1);
	DdNode *node2 = Cudd_bddXor(manager, f3, f33);
	Cudd_Ref(node2);
	DdNode *node3 = Cudd_bddXor(manager, f4, f44);
	Cudd_Ref(node3);


	nodes[0] = node0;
	nodes[1] = node1;
	nodes[2] = node2;
	nodes[3] = node3;

	Cudd_RecursiveDeref(manager, f1);
 	Cudd_RecursiveDeref(manager, f2);
 	Cudd_RecursiveDeref(manager, f3);
	Cudd_RecursiveDeref(manager, f4);
 	Cudd_RecursiveDeref(manager, f11);
 	Cudd_RecursiveDeref(manager, f22);
	Cudd_RecursiveDeref(manager, f33);
 	Cudd_RecursiveDeref(manager, f44);
	//求解
	
	/*/
	//接口一部分 weightedlist由forte产生并输入到文件
	char* filename = ("c499.bench.weight");
	//char* filename = ("c17.bench.weight");
	vector<DdNode*> bddVect;

	int count = 0;
	DdNode **nodes = compile("c499.bench.smt", bddVect, manager, bvars, mapStr2IntOfWeightedList, count);
	//printf("\ncompile\n");
	//DdNode **nodes=compile("c17.bench.smt", bddVect, manager, bvars, mapStr2IntOfWeightedList, count);
	//printf("\ncompile\n");
	vector<int> weightedlist(count, 1);
	getWeightedlist(filename, weightedlist, mapStr2IntOfWeightedList);
	
	//2012-12-31
	//these are the test code added by will
	cout<<"\n****************\n";
	cout<<weightedlist.size()<<endl;
	cout<<bvars.size()<<endl;
	cout<<"****************\n";
	//end code

	HL(manager, nodes, bvars, weightedlist);
	SA(manager, nodes, bvars, weightedlist);
	GA(manager, nodes, bvars, weightedlist);

	printf("\ntest over\n");
	Cudd_Quit(manager);
	return 0;
}


